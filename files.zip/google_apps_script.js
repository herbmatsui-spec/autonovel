// ============================================================
// 御請求明細書 自動生成スクリプト（Google Apps Script）
// ============================================================
// 使い方:
//   1. Googleフォームの回答スプレッドシートを開く
//   2. 拡張機能 > Apps Script で貼り付ける
//   3. 「請求書を生成」メニューから実行
// ============================================================

// ---- 設定 ----
const TEMPLATE_SHEET_NAME = "請求書テンプレート";  // テンプレートシート名
const FORM_SHEET_NAME     = "フォームの回答 1";    // フォーム回答シート名
const OUTPUT_FOLDER_NAME  = "請求書PDF";            // 出力フォルダ名

// ---- メニュー追加 ----
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("📄 請求書管理")
    .addItem("✅ 選択行の請求書を生成", "generateSelectedRow")
    .addItem("📦 全行の請求書を一括生成", "generateAllRows")
    .addToUi();
}

// ---- 選択行を処理 ----
function generateSelectedRow() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(FORM_SHEET_NAME);
  const row   = sheet.getActiveCell().getRow();
  if (row <= 1) { SpreadsheetApp.getUi().alert("ヘッダー行は選択できません"); return; }
  processRow(sheet, row);
  SpreadsheetApp.getUi().alert("✅ 請求書を生成しました");
}

// ---- 全行一括処理 ----
function generateAllRows() {
  const sheet    = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(FORM_SHEET_NAME);
  const lastRow  = sheet.getLastRow();
  for (let r = 2; r <= lastRow; r++) {
    processRow(sheet, r);
  }
  SpreadsheetApp.getUi().alert(`✅ ${lastRow - 1}件の請求書を生成しました`);
}

// ---- 1行分の処理 ----
function processRow(sheet, row) {
  const ss   = SpreadsheetApp.getActiveSpreadsheet();
  const data = getRowData(sheet, row);

  // テンプレートシートを複製
  const tmpl = ss.getSheetByName(TEMPLATE_SHEET_NAME);
  const copy = tmpl.copyTo(ss);
  copy.setName(`${data.roomNo}_${data.userName}`);

  // 値を書き込む
  fillTemplate(copy, data);

  // PDF出力
  exportToPDF(ss, copy, data);

  // 複製シートを削除（PDF化後は不要）
  ss.deleteSheet(copy);
}

// ---- フォーム回答行からデータを取得 ----
// ※列順はGoogleフォームの質問順と一致させること
function getRowData(sheet, row) {
  const h = getHeaders(sheet);           // ヘッダー→列番号マップ
  const r = sheet.getRange(row, 1, 1, sheet.getLastColumn()).getValues()[0];

  const get = (label) => r[h[label]] ?? "";

  // -- 基本情報 --
  const d = {
    timestamp  : get("タイムスタンプ"),
    year       : get("請求年"),
    month      : get("請求月（対象サービス月）"),
    billingDay : get("請求日"),
    roomNo     : get("部屋番号"),
    userName   : get("利用者氏名"),
    facility   : get("事業所"),

    // -- 利用料（固定・非課税）--
    riyoryoTanka      : get("利用料　単価"),
    riyoryoSu         : get("利用料　数量"),
    kanriryoTanka     : get("管理料　単価"),
    kanriryoSu        : get("管理料　数量"),
    kyoyakuTanka      : get("共益費　単価"),
    kyoyakuSu         : get("共益費　数量"),

    // -- サービス料 --
    shokujiSu         : get("食事　日数"),
    shokujiTanka      : get("食事　単価"),
    yuryoKesshokuSu   : get("有料欠食　回数"),      // デイ等で欠食
    yuryoKesshokuTanka: get("有料欠食　単価（例：-500）"),

    // -- サービス料（その他、最大5件）--
    service1Name : get("サービス1　内容"),
    service1Su   : get("サービス1　数量"),
    service1Tanka: get("サービス1　単価"),
    service2Name : get("サービス2　内容"),
    service2Su   : get("サービス2　数量"),
    service2Tanka: get("サービス2　単価"),
    service3Name : get("サービス3　内容"),
    service3Su   : get("サービス3　数量"),
    service3Tanka: get("サービス3　単価"),
    service4Name : get("サービス4　内容"),
    service4Su   : get("サービス4　数量"),
    service4Tanka: get("サービス4　単価"),
    service5Name : get("サービス5　内容"),
    service5Su   : get("サービス5　数量"),
    service5Tanka: get("サービス5　単価"),

    // -- 消耗品（最大8件）--
    syomo1Name : get("消耗品1　品名"),
    syomo1Su   : get("消耗品1　数量"),
    syomo1Unit : get("消耗品1　単位"),
    syomo1Tanka: get("消耗品1　単価"),
    syomo2Name : get("消耗品2　品名"),
    syomo2Su   : get("消耗品2　数量"),
    syomo2Unit : get("消耗品2　単位"),
    syomo2Tanka: get("消耗品2　単価"),
    syomo3Name : get("消耗品3　品名"),
    syomo3Su   : get("消耗品3　数量"),
    syomo3Unit : get("消耗品3　単位"),
    syomo3Tanka: get("消耗品3　単価"),
    syomo4Name : get("消耗品4　品名"),
    syomo4Su   : get("消耗品4　数量"),
    syomo4Unit : get("消耗品4　単位"),
    syomo4Tanka: get("消耗品4　単価"),
    syomo5Name : get("消耗品5　品名"),
    syomo5Su   : get("消耗品5　数量"),
    syomo5Unit : get("消耗品5　単位"),
    syomo5Tanka: get("消耗品5　単価"),
    syomo6Name : get("消耗品6　品名"),
    syomo6Su   : get("消耗品6　数量"),
    syomo6Unit : get("消耗品6　単位"),
    syomo6Tanka: get("消耗品6　単価"),
    syomo7Name : get("消耗品7　品名"),
    syomo7Su   : get("消耗品7　数量"),
    syomo7Unit : get("消耗品7　単位"),
    syomo7Tanka: get("消耗品7　単価"),
    syomo8Name : get("消耗品8　品名"),
    syomo8Su   : get("消耗品8　数量"),
    syomo8Unit : get("消耗品8　単位"),
    syomo8Tanka: get("消耗品8　単価"),
  };
  return d;
}

// ---- テンプレートシートへの書き込み ----
// ※セル番地は既存Excelの構造に対応
function fillTemplate(ws, d) {
  // ヘッダー部
  ws.getRange("J2").setValue(d.year);
  ws.getRange("K2").setValue(Number(d.month));
  ws.getRange("M2").setValue(d.billingDay + "日");
  ws.getRange("F3").setValue(Number(d.month));
  ws.getRange("H3").setValue(d.roomNo);
  ws.getRange("J3").setValue(d.userName);

  // 利用料（非課税）
  ws.getRange("D6").setValue(d.riyoryoSu  || 1);
  ws.getRange("F6").setValue(d.riyoryoTanka);
  ws.getRange("D7").setValue(d.kanriryoSu || 1);
  ws.getRange("F7").setValue(d.kanriryoTanka);
  ws.getRange("D8").setValue(d.kyoyakuSu  || 1);
  ws.getRange("F8").setValue(d.kyoyakuTanka);

  // サービス料
  ws.getRange("D13").setValue(d.shokujiSu);
  ws.getRange("F13").setValue(d.shokujiTanka || 1300);
  ws.getRange("D14").setValue(d.yuryoKesshokuSu);
  ws.getRange("F14").setValue(d.yuryoKesshokuTanka || -500);

  // サービス料（その他 最大5件: 行15〜19）
  const services = [
    [d.service1Name, d.service1Su, d.service1Tanka],
    [d.service2Name, d.service2Su, d.service2Tanka],
    [d.service3Name, d.service3Su, d.service3Tanka],
    [d.service4Name, d.service4Su, d.service4Tanka],
    [d.service5Name, d.service5Su, d.service5Tanka],
  ];
  services.forEach(([name, su, tanka], i) => {
    const r = 15 + i;
    if (name) {
      ws.getRange(`C${r}`).setValue(name);
      ws.getRange(`D${r}`).setValue(su);
      ws.getRange(`F${r}`).setValue(tanka);
    }
  });

  // 消耗品（最大8件: 行6〜13）
  const syomos = [
    [d.syomo1Name, d.syomo1Su, d.syomo1Unit, d.syomo1Tanka],
    [d.syomo2Name, d.syomo2Su, d.syomo2Unit, d.syomo2Tanka],
    [d.syomo3Name, d.syomo3Su, d.syomo3Unit, d.syomo3Tanka],
    [d.syomo4Name, d.syomo4Su, d.syomo4Unit, d.syomo4Tanka],
    [d.syomo5Name, d.syomo5Su, d.syomo5Unit, d.syomo5Tanka],
    [d.syomo6Name, d.syomo6Su, d.syomo6Unit, d.syomo6Tanka],
    [d.syomo7Name, d.syomo7Su, d.syomo7Unit, d.syomo7Tanka],
    [d.syomo8Name, d.syomo8Su, d.syomo8Unit, d.syomo8Tanka],
  ];
  syomos.forEach(([name, su, unit, tanka], i) => {
    const r = 6 + i;
    if (name) {
      ws.getRange(`I${r}`).setValue(name);
      ws.getRange(`K${r}`).setValue(su);
      ws.getRange(`L${r}`).setValue(unit);
      ws.getRange(`M${r}`).setValue(tanka);
    }
  });
}

// ---- PDF出力 ----
function exportToPDF(ss, ws, data) {
  const folder = getOrCreateFolder(OUTPUT_FOLDER_NAME);
  const sheetId = ws.getSheetId();

  // SpreadsheetをPDFとしてエクスポートするURL生成
  const url = `https://docs.google.com/spreadsheets/d/${ss.getId()}/export`
    + `?format=pdf`
    + `&size=A4`
    + `&portrait=true`
    + `&fitw=true`
    + `&sheetnames=false`
    + `&printtitle=false`
    + `&pagenumbers=false`
    + `&gridlines=false`
    + `&fzr=false`
    + `&gid=${sheetId}`;

  const token = ScriptApp.getOAuthToken();
  const res   = UrlFetchApp.fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  const blob  = res.getBlob().setName(`${data.roomNo}_${data.userName}_${data.year}年${data.month}月.pdf`);
  folder.createFile(blob);
}

// ---- フォルダ取得 or 作成 ----
function getOrCreateFolder(name) {
  const it = DriveApp.getFoldersByName(name);
  return it.hasNext() ? it.next() : DriveApp.createFolder(name);
}

// ---- ヘッダー行から列インデックスマップを作成 ----
function getHeaders(sheet) {
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const map = {};
  headers.forEach((h, i) => { map[h] = i; });
  return map;
}
